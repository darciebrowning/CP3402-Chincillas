<?php

$this->add_ace_editor(
	array(
		'group_id'			=> 'style', 
		'option_id'			=> 'custom-css', 
		'title'				=> __( 'Custom CSS ' , 'suppa_menu' ), 	
		'desc'				=> __( 'Add your custom css' , 'suppa_menu' ), 	
		'value'				=> '', 	
		'fetch'				=> 'yes',
	)
);