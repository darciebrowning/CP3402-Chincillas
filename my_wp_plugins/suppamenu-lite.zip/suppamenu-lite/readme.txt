=== Suppamenu ( Lite ) - Wordpress Mega Menu  ===
Contributors: codezag
Tags: menus,dropdown,wordpress mega menu, wordpress menu, drag-and-drop, dropdown menu, icons, mega menu, megamenu, menu, menu icons, menu style, navigation, responsive, responsive menu, retina
Requires at least: 3.8
Tested up to: 4.2.2
Stable tag: 1.5.3

Wordpress mega menu, that allow you to build unlimited mega menus on the same page/site. Select a skin for each menu and you can create your own skin!

== Description ==

Pro Version
https://www.youtube.com/watch?v=DDQKtHaUyMY

An excellent responsive, Customizable, Powerfull and User-Friendly WordPress Mega Menus plugin, That Allows you to create unlimited mega menus with different sub-menus types :

* Recent Posts
* Dropdowns ( 3 Levels )
* Social Media
* Search Box
* Layout & Logo

**Customization**

Suppa comes with more than 10 skin, you can choose from these skins or you can create your own skin from the admin panel and save it ( no code / just options ) !

you can play with :

* Background ( Colors, Images, Positions â€¦)
* Colors
* Box Shadow
* Borders
* Border Radius
* Gradient ( Colors & Directions )
* Font ( Select Google Fonts, Sizes, Weights & Colors )
* Icon ( Sizes, Colors )
* Arrow ( Sizes, Colors, Margins )
* And More !

**Easy to use ( User Friendly )**

* Works out of the box with any theme support WordPress 3.0 Menus.
* Works also with themes that does not support WordPress 3.0 Menus.
* Build Multi-Functional Menus from your pages, posts, categories, custom post types, ..

**WPML & Localisation**

* Suppa is WPML Ready, in case you want to run multiple languages at once!
* Localisation Ready (.po & .mo ), in case you want to translate it to your own language.

**Languages**

* English
* Italien Language, Thanks to Angelo Giammarresi http://www.laplandinteractive.com/
* French, Thanks to Google Translate

**Upgrade to Pro Version And Get**

* Sticky Menu
* Woocommerce Cart
* Mega Posts : [Sub Type]
* Mega Links : [Sub Type]
* Mega Links Type {2} : [Sub Type]
* HTML & Shotcodes : [Sub Type]
* Ability To Style all of these submenu types
* Life Time Support
* Documentation : http://vamospace.com/docs/suppa

**Upgrade Now <strong>http://suppamegamenu.com**

== Installation ==
Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
https://www.youtube.com/watch?v=IelbFcyL7sM

== Screenshots ==

1. Suppamenu

== Changelog ==

= 1.5.3 [05/07/2015] =

* New: Add Buttons to Top Bar ( access to admin panel & structure is easier now )
* Deleted: Unnecessary scripts ( cleaning )

= 1.5.1 [01/07/2015] =

* Fix: Admin Panel Bug

= 1.5 [28/06/2015] =

* New: Layout
* New: Social Media Links
* New: Effects For Posts Thumbnails
* Fix: Responsive dropdown link shows 3 arrows when click on it to open submenu
* Fix: Responsive Submenu not displaying correctly ( shortcodes submenu type )
* Fix: Dropdown arrow not displaying
* Fix: For a PHP Notice message
* Improved: Documentation

= 1.3 [27/01/2015] =

* New: Solution for browser cache issues
* New/Improved: Description for Links ( added on version 1.2 )
* New/Improved: More jquery easing ( added on version 1.2 )
* Improved: Top Links Border
* Improved: Theme Integration
* Improved: Plugin Updating Process

= 1.2 [19/01/2015] =

* New: Normal Search Form is Back
* Improved: Search
* Improved: Frontend Performance
* Improved: Frontend JS Code
* Improved: Backend
* Improved: Cache
* Update: Language Files
* Fix: For some bugs ( including the responsive bug )

= 1.1.9 [23/12/2014] =

* New: Added Italien Language, Thanks to Angelo Giammarresi
* Update: Language Files
* Improved: Google Fonts ( Best Improvements so Far ! )
* Improved: Performance
* Improved: Code

= 1.1.4 [5/12/2014] =

* Fix: For a bug on mobile
* Improved: Google Fonts Loader

= 1.1.2 [19/11/2014] =

* Fix: For Notices when Installing the plugin
* Fix: Prevent font loader from loading a null font

= 1.1.0 [5/11/2014] =

* New: Choose the dropdown submenu open direction ( left or right ) : http://goo.gl/M5XNqI
* Update: Language Files
* Improve: Link Settings : "Show Link when user" logged in/out/both
* Improve: Performance

= 1.0 [5/11/2014] =

* First Release
