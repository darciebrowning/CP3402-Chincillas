<div class="save_box">
    <div class="span6 main_menu_wrapper">
        <input placeholder="Name Your Creation" type="text" name="save_name" class="save_name span12"><br>
        <button class="button button-primary actionSave"><?php _e('Save', 'wp-visual-slidebox-builder'); ?></button>
        <button class="button scratch"><?php _e('New', 'wp-visual-slidebox-builder'); ?></button>
        <button class="button help-me"><?php _e('Help', 'wp-visual-slidebox-builder'); ?></button>

    </div>

    <div class="lins_menu_wrapper span6">
        <a target='blank' href='http://wpvisualslideboxbuilder.com/forums/' href="">
            <?php _e('Support', 'wp-visual-slidebox-builder'); ?>
        </a>|
        <a target='blank' href="http://www.wpvisualslideboxbuilder.com/donate" href="">
            <?php _e('Donate', 'wp-visual-slidebox-builder'); ?>
        </a>
    </div>
    <div style="clear: both;"></div>
    <hr/>
    <div class="wpvsbb_resp_pack">
        <p>
           Check out PRO Version for  <a target="_blank" href="http://wpvisualslideboxbuilder.com/responsive-pack-2">Responsive & More</a>
        </p>
    </div>
</div>