<div class="row vsbb_header">
    <h1 class='span10'><?php _e('VISUAL SLIDE-BOX BUILDER - FREE', 'wp-visual-slidebox-builder'); ?></h1>
    <a class='span3 pull-right feedback' target='blank'
       href="http://wordpress.org/support/view/plugin-reviews/wp-visual-slidebox-builder">
        <img src="<?php echo plugins_url('../../img/like.png', __FILE__) ?>"/>
        We love
        your feedback </a>
</div>